from game import StoryGame

story_game = StoryGame()

if __name__ == '__main__':
    story_game.start()